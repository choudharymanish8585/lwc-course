import { LightningElement } from 'lwc';

export default class CarSearch extends LightningElement {}