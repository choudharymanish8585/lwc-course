# SimpleLightbox
Lightweight plugin for responsive lightbox images and galleries with no dependencies.

[Demo and documentation can be found here](http://dbrekalo.github.io/simpleLightbox/)
