declare module "@salesforce/contentAssetUrl/sfdcfactsacademy512" {
    var sfdcfactsacademy512: string;
    export default sfdcfactsacademy512;
}
